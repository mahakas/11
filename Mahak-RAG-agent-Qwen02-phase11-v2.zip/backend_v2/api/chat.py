from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter

from backend_v2.chat.context import ConversationContext
from backend_v2.chat.educational import EducationalChatResponse, EducationalChatService
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import SessionLocal
from backend_v2.database.models import Conversation
from backend_v2.retrieval.service import RetrievalService
from backend_v2.runtime import runtime
from backend_v2.schemas.chat import CitationOut, EducationalChatRequest, EducationalChatResponseOut

router = APIRouter(prefix="/chat", tags=["chat"])


def _build_service() -> EducationalChatService:
    return EducationalChatService(
        RetrievalService(runtime.vector_store, runtime.embedding),
        runtime.llm_orchestrator,
    )


def _conversation_context(request: EducationalChatRequest) -> ConversationContext:
    db = SessionLocal()
    try:
        conversation = db.get(Conversation, request.conversation_id)
        file_ids = list(request.session_file_ids)
        if not file_ids and conversation is not None:
            file_ids = [row.id for row in getattr(conversation, "session_files", [])]
        return ConversationContext(
            conversation_id=request.conversation_id,
            user_id=conversation.user_id if conversation else None,
            mode=ChatMode.EDUCATIONAL,
            grade_id=request.grade_id or (conversation.grade_id if conversation else None),
            subject_id=request.subject_id or (conversation.subject_id if conversation else None),
            course_id=request.course_id or (conversation.course_id if conversation else None),
            chapter_id=request.chapter_id or (conversation.chapter_id if conversation else None),
            lesson_id=request.lesson_id or (conversation.lesson_id if conversation else None),
            session_file_ids=file_ids,
        )
    finally:
        db.close()


@router.post("/educational", response_model=EducationalChatResponseOut)
def educational_chat(request: EducationalChatRequest):
    context = _conversation_context(request)
    result: EducationalChatResponse = _build_service().ask(
        context,
        request.query,
        has_file=bool(context.session_file_ids),
    )
    return EducationalChatResponseOut(
        answer=result.answer,
        found=result.found,
        retrieval_count=result.retrieval_count,
        provider=result.provider,
        model=result.model,
        fallback_available=result.fallback_available,
        citations=[CitationOut(**asdict(citation)) for citation in result.citations],
    )

@router.get("/conversations/{conversation_id}/history")
def conversation_history(conversation_id: str, limit: int = 100):
    from backend_v2.services.chat_persistence import ChatPersistenceService
    return ChatPersistenceService().history(conversation_id, limit=max(1, min(limit, 200)))
