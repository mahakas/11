from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

from backend_v2.core.enums import Capability
from backend_v2.providers.contracts import ProviderRequest, ProviderResponse
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.resolver import ProviderResolver, ProviderSelection


@dataclass(frozen=True, slots=True)
class OrchestrationResult:
    response: ProviderResponse
    attempts: int
    selection: ProviderSelection


class ProviderOrchestrator:
    """Executes a capability request with ranked selection and health-aware fallback."""

    def __init__(
        self,
        registry: ProviderRegistry,
        health: ProviderHealthManager | None = None,
        *,
        max_attempts: int = 3,
        retry_backoff_seconds: float = 0.0,
        sleeper: Callable[[float], None] = time.sleep,
    ) -> None:
        self.health = health or ProviderHealthManager()
        self.registry = registry
        self.resolver = ProviderResolver(registry, self.health)
        self.max_attempts = max(1, max_attempts)
        self.retry_backoff_seconds = max(0.0, retry_backoff_seconds)
        self._sleep = sleeper

    def execute(self, capability: Capability, payload: Any, *, metadata: dict[str, Any] | None = None) -> OrchestrationResult:
        errors: list[str] = []
        attempts = 0
        metadata = metadata or {}

        for selection in self.resolver.rank(capability):
            if attempts >= self.max_attempts:
                break
            attempts += 1
            provider_name = selection.provider.adapter.provider_name
            request = ProviderRequest(
                capability=capability,
                model=selection.model,
                payload=payload,
                metadata=metadata,
            )
            started = time.perf_counter()
            try:
                response = selection.provider.adapter.execute(request)
                latency_ms = response.latency_ms
                if latency_ms is None:
                    latency_ms = (time.perf_counter() - started) * 1000
                    response = ProviderResponse(
                        output=response.output,
                        provider=response.provider,
                        model=response.model,
                        latency_ms=latency_ms,
                        metadata=response.metadata,
                    )
                self.health.record_success(provider_name, capability)
                return OrchestrationResult(response=response, attempts=attempts, selection=selection)
            except Exception as exc:  # provider-specific errors must not kill fallback chain
                errors.append(f"{provider_name}/{selection.model}: {exc}")
                self.health.record_failure(provider_name, capability, exc)
                if self.retry_backoff_seconds:
                    self._sleep(self.retry_backoff_seconds * attempts)

        joined = "; ".join(errors) if errors else "no compatible healthy provider"
        raise RuntimeError(f"Provider orchestration failed for {capability.value}: {joined}")
