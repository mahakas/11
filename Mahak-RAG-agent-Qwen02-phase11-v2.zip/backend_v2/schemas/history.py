from __future__ import annotations
from pydantic import BaseModel, Field

class HistoryCitationOut(BaseModel):
    id: str
    source_id: str | None
    title: str
    url: str | None = None
    page: int | None = None
    start_time_seconds: int | None = None
    end_time_seconds: int | None = None
    preview: str | None = None
    metadata: dict = Field(default_factory=dict)

class HistoryMessageOut(BaseModel):
    id: str
    role: str
    content: str
    metadata: dict = Field(default_factory=dict)
    created_at: str
    citations: list[HistoryCitationOut] = Field(default_factory=list)
