from __future__ import annotations

from pydantic import BaseModel, Field

from backend_v2.core.enums import SourceStatus, SourceType


class SessionUploadResponse(BaseModel):
    session_file_id: str
    source_id: str
    conversation_id: str
    filename: str
    source_type: SourceType
    status: SourceStatus
    size_bytes: int
    ready_for_context: bool
    required_capabilities: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    chunk_count: int = 0
    indexed_chunks: int = 0
