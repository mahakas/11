from __future__ import annotations

from pydantic import BaseModel, Field


class EducationalChatRequest(BaseModel):
    conversation_id: str = Field(min_length=1)
    query: str = Field(min_length=1, max_length=8000)
    grade_id: str | None = None
    subject_id: str | None = None
    course_id: str | None = None
    chapter_id: str | None = None
    lesson_id: str | None = None
    session_file_ids: list[str] = Field(default_factory=list)


class CitationOut(BaseModel):
    source_id: str | None
    title: str
    url: str | None = None
    page: int | None = None
    start_time_seconds: int | None = None
    end_time_seconds: int | None = None
    preview: str | None = None


class EducationalChatResponseOut(BaseModel):
    answer: str
    found: bool
    retrieval_count: int
    provider: str | None = None
    model: str | None = None
    fallback_available: bool = True
    citations: list[CitationOut] = Field(default_factory=list)
