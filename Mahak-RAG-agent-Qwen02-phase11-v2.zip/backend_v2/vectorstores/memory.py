from __future__ import annotations

from typing import Any

from backend_v2.vectorstores.base import VectorHit, VectorRecord


def _cosine(a: list[float], b: list[float]) -> float:
    if len(a) != len(b) or not a or not b:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(y * y for y in b) ** 0.5
    if na == 0 or nb == 0:
        return 0.0
    return max(0.0, min(1.0, dot / (na * nb)))


def _match(metadata: dict[str, Any], filters: dict[str, Any] | None) -> bool:
    if not filters:
        return True
    for key, expected in filters.items():
        actual = metadata.get(key)
        if isinstance(expected, dict) and "$in" in expected:
            if actual not in expected["$in"]:
                return False
        elif actual != expected:
            return False
    return True


class InMemoryVectorStore:
    """Deterministic local VectorStore useful for tests and lightweight development."""

    name = "memory"

    def __init__(self) -> None:
        self._collections: dict[str, dict[str, VectorRecord]] = {}

    def upsert(self, records: list[VectorRecord], *, collection: str) -> None:
        bucket = self._collections.setdefault(collection, {})
        for record in records:
            bucket[record.id] = record

    def search(
        self,
        query_embedding: list[float],
        *,
        collection: str,
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
    ) -> list[VectorHit]:
        bucket = self._collections.get(collection, {})
        hits = [
            VectorHit(r.id, _cosine(query_embedding, r.embedding), r.document, dict(r.metadata))
            for r in bucket.values()
            if _match(r.metadata, filters)
        ]
        hits.sort(key=lambda hit: (hit.score, hit.id), reverse=True)
        return hits[: max(0, int(top_k))]

    def delete(self, ids: list[str], *, collection: str) -> None:
        bucket = self._collections.get(collection, {})
        for record_id in ids:
            bucket.pop(record_id, None)

    def health_check(self) -> bool:
        return True

    def count(self, *, collection: str) -> int:
        return len(self._collections.get(collection, {}))
