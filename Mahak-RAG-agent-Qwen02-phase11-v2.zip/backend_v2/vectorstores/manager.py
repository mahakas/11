from __future__ import annotations

from backend_v2.vectorstores.base import VectorStore


class VectorStoreManager:
    def __init__(self) -> None:
        self._stores: dict[str, VectorStore] = {}

    def register(self, store: VectorStore) -> None:
        self._stores[store.name] = store

    def get(self, name: str) -> VectorStore:
        try:
            return self._stores[name]
        except KeyError as exc:
            raise KeyError(f"Unknown vector store: {name}") from exc

    def healthy(self) -> list[str]:
        return [name for name, store in self._stores.items() if store.health_check()]
