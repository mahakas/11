from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from backend_v2.core.enums import Capability
from backend_v2.providers.orchestrator import ProviderOrchestrator


@dataclass(frozen=True, slots=True)
class EmbeddingResult:
    vectors: list[list[float]]
    provider: str
    model: str
    dimension: int


class EmbeddingService:
    """Embeds text through the capability-based provider orchestrator."""

    def __init__(self, orchestrator: ProviderOrchestrator) -> None:
        self.orchestrator = orchestrator

    def embed(self, texts: Sequence[str]) -> EmbeddingResult:
        items = [str(text) for text in texts]
        if not items:
            return EmbeddingResult([], "", "", 0)

        result = self.orchestrator.execute(
            Capability.EMBEDDING,
            {"texts": items},
            metadata={"count": len(items)},
        )
        vectors = result.response.output
        if not isinstance(vectors, list) or len(vectors) != len(items):
            raise ValueError("Embedding provider returned an invalid vector batch")
        normalized: list[list[float]] = []
        for vector in vectors:
            if not isinstance(vector, (list, tuple)) or not vector:
                raise ValueError("Embedding provider returned an invalid vector")
            normalized.append([float(value) for value in vector])
        dimension = len(normalized[0])
        if any(len(vector) != dimension for vector in normalized):
            raise ValueError("Embedding provider returned inconsistent dimensions")
        return EmbeddingResult(
            vectors=normalized,
            provider=result.response.provider,
            model=result.response.model,
            dimension=dimension,
        )
