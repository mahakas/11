from __future__ import annotations

from backend_v2.core.enums import SourceType
from backend_v2.ingestion.analyzer import FileAnalysis
from backend_v2.ingestion.document import ExtractedDocument
from backend_v2.ingestion.loaders.docx import DocxLoader
from backend_v2.ingestion.loaders.html import HtmlLoader
from backend_v2.ingestion.loaders.media import ImageLoader, VideoLoader
from backend_v2.ingestion.loaders.pdf import PdfLoader
from backend_v2.ingestion.loaders.text import TextLoader


class LoaderRegistry:
    def __init__(self) -> None:
        text_loader = TextLoader()
        self._loaders = {
            SourceType.TXT: text_loader,
            SourceType.MD: text_loader,
            SourceType.DOCX: DocxLoader(),
            SourceType.PDF: PdfLoader(),
            SourceType.HTML: HtmlLoader(),
            SourceType.IMAGE: ImageLoader(),
            SourceType.VIDEO: VideoLoader(),
        }

    def load(self, analysis: FileAnalysis) -> ExtractedDocument:
        loader = self._loaders.get(analysis.source_type)
        if loader is None:
            raise ValueError(f"Unsupported source type: {analysis.source_type}")
        return loader.load(analysis)
