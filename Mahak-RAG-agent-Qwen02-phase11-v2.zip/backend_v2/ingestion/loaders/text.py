from __future__ import annotations

from pathlib import Path

from backend_v2.ingestion.analyzer import FileAnalysis
from backend_v2.ingestion.document import ExtractedDocument
from backend_v2.ingestion.loaders.base import require_exists


class TextLoader:
    def load(self, analysis: FileAnalysis) -> ExtractedDocument:
        require_exists(analysis.path)
        text = analysis.path.read_text(encoding="utf-8-sig", errors="replace")
        title = analysis.path.stem.replace("_", " ").replace("-", " ").strip() or analysis.path.name
        return ExtractedDocument(
            source_type=analysis.source_type,
            text=text,
            title=title,
            metadata={"path": str(analysis.path), "mime_type": analysis.mime_type},
        )
