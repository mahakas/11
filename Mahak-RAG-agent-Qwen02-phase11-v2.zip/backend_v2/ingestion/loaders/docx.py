from __future__ import annotations

from docx import Document

from backend_v2.ingestion.analyzer import FileAnalysis
from backend_v2.ingestion.document import ExtractedDocument
from backend_v2.ingestion.loaders.base import require_exists


class DocxLoader:
    def load(self, analysis: FileAnalysis) -> ExtractedDocument:
        require_exists(analysis.path)
        document = Document(analysis.path)
        paragraphs = [p.text.strip() for p in document.paragraphs if p.text.strip()]
        tables: list[str] = []
        for table in document.tables:
            for row in table.rows:
                values = [cell.text.strip() for cell in row.cells]
                if any(values):
                    tables.append(" | ".join(values))
        text = "\n".join(paragraphs + tables)
        return ExtractedDocument(
            source_type=analysis.source_type,
            text=text,
            title=analysis.path.stem,
            metadata={"path": str(analysis.path), "paragraphs": len(paragraphs), "tables": len(document.tables)},
        )
