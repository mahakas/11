from pathlib import Path

from fastapi.testclient import TestClient

from backend_v2.api.app import create_app
from backend_v2.core.config import settings
import backend_v2.api.uploads as uploads_api
from dataclasses import replace


def test_session_upload_txt(tmp_path, monkeypatch):
    monkeypatch.setattr(uploads_api, "settings", replace(settings, storage_dir=tmp_path))
    client = TestClient(create_app())
    response = client.post(
        "/api/uploads/session",
        data={"conversation_id": "conv-phase9", "mode": "general"},
        files={"file": ("lesson.txt", "قانون دوم نیوتن نیرو برابر جرم ضربدر شتاب است.", "text/plain")},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["filename"] == "lesson.txt"
    assert payload["source_type"] == "txt"
    assert payload["ready_for_context"] is True
    assert payload["chunk_count"] >= 1
    assert Path(tmp_path, "sessions", "conv-phase9").exists()


def test_session_upload_uses_required_capabilities_for_image(tmp_path, monkeypatch):
    from PIL import Image
    import io

    monkeypatch.setattr(uploads_api, "settings", replace(settings, storage_dir=tmp_path))
    buffer = io.BytesIO()
    Image.new("RGB", (8, 8), "white").save(buffer, format="PNG")
    client = TestClient(create_app())
    response = client.post(
        "/api/uploads/session",
        data={"conversation_id": "conv-image", "mode": "educational"},
        files={"file": ("diagram.png", buffer.getvalue(), "image/png")},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["source_type"] == "image"
    assert "vision" in payload["required_capabilities"]
    assert payload["ready_for_context"] is False
