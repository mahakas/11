from uuid import uuid4
from backend_v2.chat.context import ConversationContext
from backend_v2.chat.educational import EducationalChatService
from backend_v2.core.enums import ChatMode
from backend_v2.database.connection import SessionLocal, create_all
from backend_v2.database.models import Citation, Conversation, Message
from backend_v2.database.repositories import CitationRepository, ConversationRepository, MessageRepository
from backend_v2.retrieval.citation_builder import CitationRef


def test_chat_repositories_persist_messages_and_citations():
    create_all()
    db = SessionLocal()
    try:
        c = ConversationRepository(db).get_or_create(
            conversation_id=str(uuid4()),
            mode=ChatMode.EDUCATIONAL,
            user_id="u1",
            grade_id="g10",
        )
        user = MessageRepository(db).create(conversation_id=c.id, role="user", content="سؤال")
        assistant = MessageRepository(db).create(conversation_id=c.id, role="assistant", content="پاسخ")
        CitationRepository(db).create(
            message_id=assistant.id,
            source_id="src-1",
            title="کتاب فیزیک",
            url="https://example.test/book.pdf",
            page=42,
            metadata_json={"source_type": "pdf"},
        )
        db.commit()
        assert len(MessageRepository(db).list(c.id)) == 2
        assert len(CitationRepository(db).list_for_conversation(c.id)) == 1
    finally:
        db.close()


def test_citation_supports_video_timestamp():
    citation = CitationRef(
        source_id="video-1",
        title="جلسه حرکت",
        url="https://example.test/video",
        start_time_seconds=742,
        end_time_seconds=824,
    )
    assert citation.start_time_seconds == 742
    assert citation.end_time_seconds == 824


def test_history_api_returns_persisted_citation():
    from fastapi.testclient import TestClient
    from backend_v2.api.app import create_app
    client = TestClient(create_app())
    db = SessionLocal()
    try:
        repo = ConversationRepository(db)
        c = repo.get_or_create(conversation_id="history-api-" + str(uuid4()), mode=ChatMode.EDUCATIONAL)
        m = MessageRepository(db).create(conversation_id=c.id, role="assistant", content="پاسخ")
        CitationRepository(db).create(message_id=m.id, source_id="src", title="منبع", url="https://example.test/a.pdf", page=3)
        db.commit()
    finally:
        db.close()
    response = client.get(f"/api/chat/conversations/{c.id}/history")
    assert response.status_code == 200
    data = response.json()
    assert data[0]["citations"][0]["url"].endswith("a.pdf")
    assert data[0]["citations"][0]["page"] == 3
