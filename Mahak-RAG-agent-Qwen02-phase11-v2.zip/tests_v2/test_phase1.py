from pathlib import Path

from backend_v2.chat.context import ConversationContext
from backend_v2.chat.planner import QueryPlanner
from backend_v2.core.enums import Capability, ChatMode, SourceType
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.providers.resolver import ProviderResolver
from backend_v2.providers.contracts import ProviderRequest, ProviderResponse
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.threshold import RetrievalThreshold
from backend_v2.vectorstores.base import VectorHit


class FakeAdapter:
    provider_name = "fake"

    def supports(self, capability: Capability) -> bool:
        return capability is Capability.CHAT

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        return ProviderResponse(output="ok", provider=self.provider_name, model=request.model)

    def health_check(self, capability=None) -> bool:
        return True


def test_educational_scope_and_plan():
    ctx = ConversationContext("c1", None, ChatMode.EDUCATIONAL, grade_id="g1", subject_id="s1")
    plan = QueryPlanner().plan(ctx)
    assert plan.enabled is True
    assert plan.allow_web is False


def test_general_chat_allows_web():
    ctx = ConversationContext("c1", None, ChatMode.GENERAL)
    plan = QueryPlanner().plan(ctx)
    assert plan.enabled is False
    assert plan.allow_web is True


def test_provider_resolution_by_capability():
    registry = ProviderRegistry()
    registry.register(FakeAdapter(), priority=1)
    selected = ProviderResolver(registry).select(Capability.CHAT)
    assert selected.provider.adapter.provider_name == "fake"


def test_health_circuit_opens():
    health = ProviderHealthManager(failure_threshold=2, cooldown_seconds=60)
    health.record_failure("fake", Capability.CHAT, RuntimeError("boom"))
    assert health.is_available("fake", Capability.CHAT)
    health.record_failure("fake", Capability.CHAT, RuntimeError("boom"))
    assert not health.is_available("fake", Capability.CHAT)


def test_retrieval_scope_filters_only_set_values():
    filters = RetrievalScope(grade_id="g1", subject_id="s1").as_filters()
    assert filters == {"grade_id": "g1", "subject_id": "s1"}


def test_retrieval_threshold():
    hits = [
        VectorHit("1", 0.9, "a", {}),
        VectorHit("2", 0.2, "b", {}),
    ]
    decision = RetrievalThreshold(0.35).apply(hits)
    assert [h.id for h in decision.accepted] == ["1"]


def test_ingestion_type_detection():
    analyzed = IngestionPipeline().analyze(Path("lesson.pdf"))
    assert analyzed.source_type is SourceType.PDF
    assert analyzed.requires_vision is False

    analyzed_image = IngestionPipeline().analyze(Path("lesson.png"))
    assert analyzed_image.source_type is SourceType.IMAGE
    assert analyzed_image.requires_vision is True
